module Leave_Management {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
