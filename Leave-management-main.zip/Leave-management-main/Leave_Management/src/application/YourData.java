package application;

public class YourData {
	private int sno;
    private String empId;
    private String empName;
    private String reason;
    private String date;
	public void setEmpId(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setSno(int int1) {
		// TODO Auto-generated method stub
		
	}
	public void setReason(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setEmpName(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setDate(String string) {
		// TODO Auto-generated method stub
		
	}

}
